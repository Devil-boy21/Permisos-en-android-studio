# ImageApp
El usuario podra tomar las fotos que desee , elegir la foto que se guardo desde el foton save , para ver en la imageview es decir en la pantalla del celular cuenta ademas con una interfaz agradable y con permisos de camara y mensajes de alerta. 
